﻿namespace DataCollection
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pictureBox1 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            tb_DataIn = new TextBox();
            tb_FileSave = new TextBox();
            label1 = new Label();
            label2 = new Label();
            cmbo_cameras = new ComboBox();
            cmbo_Ports = new ComboBox();
            cmbo_Baud = new ComboBox();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            tabPage2 = new TabPage();
            hScrollBar1 = new HScrollBar();
            groupBox2 = new GroupBox();
            indicator_spray = new ProgressBar();
            spray_label = new Label();
            sprayprogress = new ProgressBar();
            label3 = new Label();
            mm = new Label();
            tb_sprayLoc = new TextBox();
            btn_StopSpray = new Button();
            btn_StartSpray = new Button();
            groupBox1 = new GroupBox();
            indicator_detect = new ProgressBar();
            button_stopdetect = new Button();
            btn_StartRobot = new Button();
            formsPlot1 = new ScottPlot.WinForms.FormsPlot();
            tabPage3 = new TabPage();
            timer_UpdateChart = new System.Windows.Forms.Timer(components);
            timer1 = new System.Windows.Forms.Timer(components);
            checkData = new System.Windows.Forms.Timer(components);
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            groupBox3 = new GroupBox();
            groupBox4 = new GroupBox();
            timer_Spray = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(35, 19);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(795, 621);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.Location = new Point(191, 66);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 2;
            button1.Text = "list";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(191, 106);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 3;
            button2.Text = "selelct";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(192, 111);
            button3.Name = "button3";
            button3.Size = new Size(112, 34);
            button3.TabIndex = 6;
            button3.Text = "select";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(192, 71);
            button4.Name = "button4";
            button4.Size = new Size(112, 34);
            button4.TabIndex = 5;
            button4.Text = "list";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(49, 641);
            button5.Name = "button5";
            button5.Size = new Size(285, 34);
            button5.TabIndex = 7;
            button5.Text = "Start Collecting Data";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // tb_DataIn
            // 
            tb_DataIn.Location = new Point(49, 448);
            tb_DataIn.Multiline = true;
            tb_DataIn.Name = "tb_DataIn";
            tb_DataIn.Size = new Size(285, 92);
            tb_DataIn.TabIndex = 8;
            // 
            // tb_FileSave
            // 
            tb_FileSave.Location = new Point(49, 582);
            tb_FileSave.Multiline = true;
            tb_FileSave.Name = "tb_FileSave";
            tb_FileSave.Size = new Size(285, 35);
            tb_FileSave.TabIndex = 9;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(49, 420);
            label1.Name = "label1";
            label1.Size = new Size(73, 25);
            label1.TabIndex = 10;
            label1.Text = "Data In:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(49, 554);
            label2.Name = "label2";
            label2.Size = new Size(116, 25);
            label2.TabIndex = 11;
            label2.Text = "File Names(s)";
            // 
            // cmbo_cameras
            // 
            cmbo_cameras.FormattingEnabled = true;
            cmbo_cameras.Location = new Point(15, 30);
            cmbo_cameras.Name = "cmbo_cameras";
            cmbo_cameras.Size = new Size(285, 33);
            cmbo_cameras.TabIndex = 12;
            // 
            // cmbo_Ports
            // 
            cmbo_Ports.FormattingEnabled = true;
            cmbo_Ports.Location = new Point(11, 30);
            cmbo_Ports.Name = "cmbo_Ports";
            cmbo_Ports.Size = new Size(293, 33);
            cmbo_Ports.TabIndex = 13;
            // 
            // cmbo_Baud
            // 
            cmbo_Baud.FormattingEnabled = true;
            cmbo_Baud.Location = new Point(10, 72);
            cmbo_Baud.Name = "cmbo_Baud";
            cmbo_Baud.Size = new Size(152, 33);
            cmbo_Baud.TabIndex = 14;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Location = new Point(346, 15);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(883, 694);
            tabControl1.TabIndex = 15;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(pictureBox1);
            tabPage1.Location = new Point(4, 34);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(875, 656);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Video Feed";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(hScrollBar1);
            tabPage2.Controls.Add(groupBox2);
            tabPage2.Controls.Add(groupBox1);
            tabPage2.Controls.Add(formsPlot1);
            tabPage2.Location = new Point(4, 34);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(875, 656);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Temperature Monitor";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // hScrollBar1
            // 
            hScrollBar1.Location = new Point(392, 504);
            hScrollBar1.Name = "hScrollBar1";
            hScrollBar1.Size = new Size(462, 70);
            hScrollBar1.TabIndex = 4;
            hScrollBar1.ValueChanged += hScrollBar1_ValueChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(indicator_spray);
            groupBox2.Controls.Add(spray_label);
            groupBox2.Controls.Add(sprayprogress);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(mm);
            groupBox2.Controls.Add(tb_sprayLoc);
            groupBox2.Controls.Add(btn_StopSpray);
            groupBox2.Controls.Add(btn_StartSpray);
            groupBox2.Location = new Point(26, 212);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(315, 404);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "SPRAY";
            // 
            // indicator_spray
            // 
            indicator_spray.Location = new Point(198, 152);
            indicator_spray.Name = "indicator_spray";
            indicator_spray.Size = new Size(63, 57);
            indicator_spray.TabIndex = 7;
            // 
            // spray_label
            // 
            spray_label.AutoSize = true;
            spray_label.Location = new Point(29, 337);
            spray_label.Name = "spray_label";
            spray_label.Size = new Size(0, 25);
            spray_label.TabIndex = 6;
            // 
            // sprayprogress
            // 
            sprayprogress.Location = new Point(25, 266);
            sprayprogress.Name = "sprayprogress";
            sprayprogress.Size = new Size(265, 57);
            sprayprogress.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(25, 74);
            label3.Name = "label3";
            label3.Size = new Size(123, 25);
            label3.TabIndex = 4;
            label3.Text = "spray location";
            // 
            // mm
            // 
            mm.AutoSize = true;
            mm.Location = new Point(246, 74);
            mm.Name = "mm";
            mm.Size = new Size(44, 25);
            mm.TabIndex = 3;
            mm.Text = "mm";
            // 
            // tb_sprayLoc
            // 
            tb_sprayLoc.Location = new Point(154, 71);
            tb_sprayLoc.Name = "tb_sprayLoc";
            tb_sprayLoc.Size = new Size(80, 31);
            tb_sprayLoc.TabIndex = 2;
            // 
            // btn_StopSpray
            // 
            btn_StopSpray.Enabled = false;
            btn_StopSpray.Location = new Point(25, 192);
            btn_StopSpray.Name = "btn_StopSpray";
            btn_StopSpray.Size = new Size(135, 43);
            btn_StopSpray.TabIndex = 1;
            btn_StopSpray.Text = "STOP";
            btn_StopSpray.UseVisualStyleBackColor = true;
            // 
            // btn_StartSpray
            // 
            btn_StartSpray.Enabled = false;
            btn_StartSpray.Location = new Point(25, 134);
            btn_StartSpray.Name = "btn_StartSpray";
            btn_StartSpray.Size = new Size(135, 43);
            btn_StartSpray.TabIndex = 0;
            btn_StartSpray.Text = "START";
            btn_StartSpray.UseVisualStyleBackColor = true;
            btn_StartSpray.Click += btn_StartSpray_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(indicator_detect);
            groupBox1.Controls.Add(button_stopdetect);
            groupBox1.Controls.Add(btn_StartRobot);
            groupBox1.Location = new Point(26, 32);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(315, 150);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "DETECTION";
            // 
            // indicator_detect
            // 
            indicator_detect.Location = new Point(39, 49);
            indicator_detect.Name = "indicator_detect";
            indicator_detect.Size = new Size(63, 57);
            indicator_detect.TabIndex = 6;
            // 
            // button_stopdetect
            // 
            button_stopdetect.Enabled = false;
            button_stopdetect.Location = new Point(138, 86);
            button_stopdetect.Name = "button_stopdetect";
            button_stopdetect.Size = new Size(135, 43);
            button_stopdetect.TabIndex = 1;
            button_stopdetect.Text = "STOP";
            button_stopdetect.UseVisualStyleBackColor = true;
            button_stopdetect.Click += button_stopdetect_Click;
            // 
            // btn_StartRobot
            // 
            btn_StartRobot.Location = new Point(138, 25);
            btn_StartRobot.Name = "btn_StartRobot";
            btn_StartRobot.Size = new Size(135, 43);
            btn_StartRobot.TabIndex = 0;
            btn_StartRobot.Text = "START";
            btn_StartRobot.UseVisualStyleBackColor = true;
            btn_StartRobot.Click += btn_StartRobot_Click;
            // 
            // formsPlot1
            // 
            formsPlot1.DisplayScale = 1.5F;
            formsPlot1.Location = new Point(357, 32);
            formsPlot1.Name = "formsPlot1";
            formsPlot1.Size = new Size(512, 430);
            formsPlot1.TabIndex = 0;
            // 
            // tabPage3
            // 
            tabPage3.Location = new Point(4, 34);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(875, 656);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Radiation Monitor";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // timer_UpdateChart
            // 
            timer_UpdateChart.Tick += timer_UpdateChart_Tick;
            // 
            // checkData
            // 
            checkData.Tick += checkData_Tick;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(button2);
            groupBox3.Controls.Add(button1);
            groupBox3.Controls.Add(cmbo_cameras);
            groupBox3.Location = new Point(6, 237);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(329, 169);
            groupBox3.TabIndex = 16;
            groupBox3.TabStop = false;
            groupBox3.Text = "Camera";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(button3);
            groupBox4.Controls.Add(button4);
            groupBox4.Controls.Add(cmbo_Ports);
            groupBox4.Controls.Add(cmbo_Baud);
            groupBox4.Location = new Point(12, 39);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(323, 183);
            groupBox4.TabIndex = 17;
            groupBox4.TabStop = false;
            groupBox4.Text = "Serial";
            // 
            // timer_Spray
            // 
            timer_Spray.Tick += timer_Spray_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1268, 733);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(tabControl1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(tb_FileSave);
            Controls.Add(tb_DataIn);
            Controls.Add(button5);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "RadWorm";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private TextBox tb_DataIn;
        private TextBox tb_FileSave;
        private Label label1;
        private Label label2;
        private ComboBox cmbo_cameras;
        private ComboBox cmbo_Ports;
        private ComboBox cmbo_Baud;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private Button button_stopdetect;
        private Button btn_StartRobot;
        private ScottPlot.WinForms.FormsPlot formsPlot1;
        private System.Windows.Forms.Timer timer_UpdateChart;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer checkData;
        private GroupBox groupBox2;
        private Label label3;
        private Label mm;
        private TextBox tb_sprayLoc;
        private Button btn_StopSpray;
        private Button btn_StartSpray;
        private GroupBox groupBox1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private HScrollBar hScrollBar1;
        private ProgressBar indicator_spray;
        private Label spray_label;
        private ProgressBar sprayprogress;
        private ProgressBar indicator_detect;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private System.Windows.Forms.Timer timer_Spray;
    }
}