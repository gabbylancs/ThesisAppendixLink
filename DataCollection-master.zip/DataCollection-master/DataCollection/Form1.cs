
using System.IO.Ports;
using Emgu.CV;
using MediaToolkit;
using MediaToolkit.Model;
using AForge.Video;
using AForge.Video.DirectShow;
using System.Data;


using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Emgu.CV.Reg;
using Emgu.CV.Structure;
using System.Transactions;
using ScottPlot;

namespace DataCollection
{
    public partial class Form1 : Form
    {

        double[] dataX = new double[0];
        double[] dataY = new double[0];
        int k = 0;
        bool newData = false;
        string dataInString;

        public float distance = 1024;
        public float temperature = 21;
        double graphVal;
        public float barVal = 0;
        public int spraysecs = 0;

        public bool robotStopped = false;
        public bool ValuePicked = false;
        public bool sprayStarted = false;
        public ScottPlot.Plottables.LinePlot barLine;


        // Serial Stuff
        SerialPort serial = new SerialPort();
        private readonly int[] baudrate = { 4800, 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600 };
        // ---------------------------------------------------

        private bool DeviceExist = false;
        private FilterInfoCollection? videoDevices;
        private VideoCaptureDevice? videoSource = null;
        public VideoWriter videoWriter;

        public static string filename = string.Format("{0:MM-dd_hh-mm-sstt}.avi", DateTime.Now);
        public static string filenameTxt = string.Format("{0:MM-dd_hh-mm-sstt}.txt", DateTime.Now);
        public string path = @"C:\Users\blewitt.LANCS\OneDrive - Lancaster University\Third Year\Data\Cam Data " + filename;
        public string pathTxt = @"C:\Users\blewitt.LANCS\OneDrive - Lancaster University\Third Year\Data\IMU Data" + filenameTxt;
        public int codec = VideoWriter.Fourcc('M', 'J', 'P', 'G');
        public string SerialText;

        public Form1()
        {
            InitializeComponent();
        }


        //--------------------------------------------- CAMERA STUFF ----------------------------------------

        // LIST VIDEO
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                cmbo_cameras.Items.Clear();
                if (videoDevices.Count == 0)
                    throw new ApplicationException();

                DeviceExist = true;
                foreach (FilterInfo device in videoDevices)
                {
                    cmbo_cameras.Items.Add(device.Name);
                }
                cmbo_cameras.SelectedIndex = 0; //make dafault to first cam
            }
            catch (ApplicationException)
            {
                DeviceExist = false;
                cmbo_cameras.Items.Add("No capture device on your system");
            }
        }

        // START VIDEO
        private void button2_Click(object sender, EventArgs e)
        {

            if (DeviceExist)
            {
                videoSource = new VideoCaptureDevice(videoDevices[cmbo_cameras.SelectedIndex].MonikerString);
                videoSource.NewFrame += new NewFrameEventHandler(video_NewFrame);
                CloseVideoSource();
                //videoSource.DesiredFrameSize = new Size(160, 120);
                //videoSource.DesiredFrameRate = 10;
                videoSource.Start();
                label2.Text = "Device running...";

            }
            else
            {
                label2.Text = "Error: No Device selected.";
            }
        }

        // Atm just puts frame in picture box
        private void video_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            Bitmap bm_frame = (Bitmap)eventArgs.Frame.Clone();
            Mat mat = bm_frame.ToMat(); //This is your Image converted to Mat
            //do processing here
            CvInvoke.Resize(mat, mat, new Size(1920, 1080));
            pictureBox1.Image = (System.Drawing.Image)eventArgs.Frame.Clone();
            pictureBox1.Invalidate();

            if (button5.Text == "STOP")
            {// indicates we're collecting data
                videoWriter.Write(mat);
            }

            bm_frame.Dispose();
            mat.Dispose();
        }

        //close the device safely
        private void CloseVideoSource()
        {
            if (!(videoSource == null))
                if (videoSource.IsRunning)
                {
                    videoSource.SignalToStop();
                    videoSource = null;
                }
        }


        // -------------------------------- CAMERA STUFF -------------------------------------------


        // -------------------------------- SERIAL STUFF -------------------------------------------
        // LIST SERIAL
        private void button4_Click(object sender, EventArgs e)
        {
            // Get Serial Ports
            string[] Ports = System.IO.Ports.SerialPort.GetPortNames();
            cmbo_Ports.Items.Clear();
            cmbo_Baud.Items.Clear();

            foreach (string Port in Ports)
            {
                cmbo_Ports.Items.Add(Port);
            }

            foreach (var baud in baudrate)
            {
                cmbo_Baud.Items.Add(baud.ToString());
            }
        }

        // START SERIAL
        private void button3_Click(object sender, EventArgs e)
        {
            if ("disconnect" == button3.Text)
            {
                if (serial.IsOpen)
                {
                    serial.Close();
                }

                button3.Text = "select";
                cmbo_Baud.Enabled = true;
                cmbo_Ports.Enabled = true;

                return;
            }

            else
            {
                // else we'll try open it

                try
                {
                    serial.PortName = cmbo_Ports.Text;
                }
                catch
                {
                    MessageBox.Show("please select Port");
                    return;
                }

                try
                {
                    serial.BaudRate = int.Parse(cmbo_Baud.Text);
                }
                catch
                {
                    MessageBox.Show("please select Baud");
                    return;
                }


                if (serial.IsOpen == false)
                {
                    serial.Parity = Parity.None;
                    serial.DataBits = 8;
                    serial.StopBits = StopBits.One;
                    serial.Handshake = Handshake.None;
                    serial.Open();
                    serial.DataReceived += Serial_DataReceived;
                    button3.Text = "disconnect";
                }
            }

        }

        private void Serial_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            //serial.ReadTimeout = 20;

            try
            {
                string inData = serial.ReadLine();
                tb_DataIn.Invoke((Action)delegate
                {
                    tb_DataIn.Text = inData;
                });

                if (button5.Text == "STOP")
                {
                    SerialText = SerialText + inData;
                }

                // potentially it is a data update 
                if (inData.Length > 5)
                {
                    newData = true;
                    dataInString = inData;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }




        }



        // -------------------------------- SERIAL STUFF -------------------------------------------



        // ------------------------------------ RECORDINGS -----------------------------------------




        private void button5_Click(object sender, EventArgs e)
        {
            if (button5.Text == "Start Collecting Data")
            {
                videoWriter = new VideoWriter(path, codec, 1, new Size(4656, 3496), true);
                button5.Text = "STOP";
            }


            else if (button5.Text == "STOP")
            {// SAVE SERIAL TEXT FILE HERE
                button5.Text = "Start Collecting Data";
                //if (SerialText.Length > 0) { AppendToFile(SerialText); }
                if (videoWriter != null) { videoWriter.Dispose(); }
            }

        }

        // serial text recording
        private void AppendToFile(string toAppend)
        {
            File.AppendAllText(pathTxt, toAppend + Environment.NewLine);
        }

        private void btn_StartRobot_Click(object sender, EventArgs e)
        {
            if (serial.IsOpen == true)
            {
                InitializeChart();
                button_stopdetect.Enabled = true;
                timer_UpdateChart.Interval = 1000;
                timer_UpdateChart.Start();
                checkData.Interval = 1200;
                checkData.Start();
                indicator_detect.Enabled = true;
                indicator_detect.Value = 100;
            }
            else
            {
                MessageBox.Show("Connect to Serial");
            }

        }

        private void button_stopdetect_Click(object sender, EventArgs e)
        {
            //timer_UpdateChart.Stop();
            btn_StartSpray.Enabled = true;
            btn_StopSpray.Enabled = true;
            robotStopped = true;
        }

        private void btn_StartSpray_Click(object sender, EventArgs e)
        {
            timer_Spray.Interval = 1003;
            timer_Spray.Start();
            indicator_spray.Enabled = true;
            sprayprogress.Enabled = true;
            indicator_spray.Value = 100;
        }

        private void timer_UpdateChart_Tick(object sender, EventArgs e)
        {
            UpdateChart();
        }

        private void InitializeChart()
        {
            formsPlot1.Plot.XLabel("Time[s]");
            formsPlot1.Plot.YLabel("Temperature[�C]");
            formsPlot1.Plot.Title("TC-01 Temperature Sensor");
            dataX = dataX.Append(0).ToArray();
            dataY = dataY.Append(0).ToArray();
            formsPlot1.Refresh();
        }

        private double GetSensorData()
        {
            Random rand = new Random();
            double sensorValue = rand.NextDouble() * 10 + 20; //Random Value between 20 and 30
            return sensorValue;
        }

        private void UpdateChart()
        {
            k++;
            AxisLimits limits = formsPlot1.Plot.Axes.GetLimits();
            double newValue = GetSensorData();
            if (robotStopped == false)
            {
                formsPlot1.Plot.Add.Scatter(dataX, dataY);
            }
            formsPlot1.Plot.Axes.AutoScale();
            formsPlot1.Refresh();
        }

        private void checkData_Tick(object sender, EventArgs e)
        {
            //  basic protocol - lets do 11 char message
            /*
             *  [0]  --> 'A', indication of start 
             *  [1]  --> wire char 1
             *  [2]  --> wire char 2
             *  [3]  --> wire char 3
             *  [4]  --> wire char 4
             *  [5]  --> '/'
             *  [6]  --> temp char 1
             *  [7]  --> temp char 2
             *  [8]  --> '.'
             *  [9]  --> temp char 3
             * [10]  --> temp char 4
             * [11]  --> 'C'
             * [12]  --> '/n'
             * 
             */

            if (newData == true)
            {
                newData = false;
                bool messageStart = false;
                int messageInt = 0;
                int strLength = dataInString.Length;
                char[] bytes = dataInString.ToCharArray();
                char[] Wires = new char[4];
                char[] Temps = new char[5];
                dataInString = string.Empty;
                char b;

                for (int i = 0; i < strLength; i++)
                {
                    b = bytes[i];

                    if (messageStart == true)
                    {
                        if (messageInt < 5)
                        {
                            Wires[messageInt - 1] = b;
                        }
                        else if (messageInt < 11 && b != '/')
                        {
                            Temps[messageInt - 6] = b;
                        }
                        else if (messageInt == 11)
                        {
                            if (b == 'C')
                            {
                                string SWires = new string(Wires);
                                string STemps = new string(Temps);
                                float x = float.Parse(SWires);
                                temperature = float.Parse(STemps);
                                distance = 30 * (1024 - x) / 1024;

                                dataX = dataX.Append(distance).ToArray();
                                dataY = dataY.Append(temperature).ToArray();

                            }

                        }
                        messageInt++;

                    }

                    if (b == 'A')
                    {
                        messageStart = true;
                        messageInt++;
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void hScrollBar1_ValueChanged(object sender, EventArgs e)
        {
            if (ValuePicked == true) { formsPlot1.Plot.Remove(barLine); }
            barVal = hScrollBar1.Value;
            AxisLimits limits = formsPlot1.Plot.Axes.GetLimits();
            graphVal = (barVal * limits.Right) / 100;
            barLine = formsPlot1.Plot.Add.Line(graphVal, limits.Bottom, graphVal, limits.Top);
            tb_sprayLoc.Text = (10 * graphVal).ToString();
            ValuePicked = true;

        }

        private void timer_Spray_Tick(object sender, EventArgs e)
        {

            if (distance < (graphVal + 2) && distance > (graphVal - 2) && sprayStarted == false)
            {
                sprayStarted = true;
                spraysecs = 20;
                sprayprogress.Value = spraysecs;
            }
            else if (sprayStarted == true)
            {
                spraysecs += 20;
                sprayprogress.Value = spraysecs;
                if (spraysecs == 100)
                {
                    sprayStarted = false;
                }
            }
        }



        // -------------------------------- RECORDINGS -------------------------------------------
    }
}